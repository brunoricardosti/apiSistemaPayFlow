using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using PayFlow.Providers;
using PayFlow.Services;
using Serilog;
using Polly;
using Polly.Extensions.Http;
using System.Net.Http.Headers;

var builder = WebApplication.CreateBuilder(args);

// Serilog
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();

builder.Host.UseSerilog();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var config = builder.Configuration;

// Configure typed HttpClients with simple resilience policies (Polly)
IAsyncPolicy<HttpResponseMessage> GetRetryPolicy() =>
    HttpPolicyExtensions
        .HandleTransientHttpError()
        .WaitAndRetryAsync(3, retryAttempt => TimeSpan.FromMilliseconds(200 * Math.Pow(2, retryAttempt)));

builder.Services.AddHttpClient<IFastPayProvider, FastPayProvider>((sp, client) => {
    var baseUrl = config["Providers:FastPay:BaseUrl"];
    if (!string.IsNullOrWhiteSpace(baseUrl)) client.BaseAddress = new Uri(baseUrl);
    var key = config["Providers:FastPay:ApiKey"];
    if (!string.IsNullOrWhiteSpace(key)) client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", key);
}).AddPolicyHandler(GetRetryPolicy());

builder.Services.AddHttpClient<ISecurePayProvider, SecurePayProvider>((sp, client) => {
    var baseUrl = config["Providers:SecurePay:BaseUrl"];
    if (!string.IsNullOrWhiteSpace(baseUrl)) client.BaseAddress = new Uri(baseUrl);
    var token = config["Providers:SecurePay:Token"];
    if (!string.IsNullOrWhiteSpace(token)) client.DefaultRequestHeaders.Add("X-API-TOKEN", token);
}).AddPolicyHandler(GetRetryPolicy());

// Register providers as IPaymentProvider for enumeration
builder.Services.AddSingleton<IPaymentProvider>(sp => sp.GetRequiredService<IFastPayProvider>());
builder.Services.AddSingleton<IPaymentProvider>(sp => sp.GetRequiredService<ISecurePayProvider>());

// PaymentService
builder.Services.AddSingleton<PaymentService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseRouting();
app.UseSerilogRequestLogging();
app.UseAuthorization();
app.MapControllers();
app.Run();
